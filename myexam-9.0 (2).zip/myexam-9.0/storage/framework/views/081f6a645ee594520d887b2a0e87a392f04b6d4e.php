<form action="<?php echo e(route('hospital.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
  <div class="form-group">
    <label >Name</label>
    <input type="text" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label>Mobile</label>
    <input type="number" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label >Diseases</label>
    <input type="text" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label >Medicines</label>
    <input type="text" name="name" class="form-control" ">
  </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form><?php /**PATH C:\Users\milan\Desktop\MCA SEM-2\Laravel\myexam-9.0\resources\views/user/create.blade.php ENDPATH**/ ?>
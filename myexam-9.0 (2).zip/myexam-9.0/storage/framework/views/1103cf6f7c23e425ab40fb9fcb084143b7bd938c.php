<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
</body>
<h1>Oasis Hospital</h1>
<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\Users\milan\Desktop\MCA SEM-2\Laravel\myexam-9.0\resources\views/template/layout.blade.php ENDPATH**/ ?>
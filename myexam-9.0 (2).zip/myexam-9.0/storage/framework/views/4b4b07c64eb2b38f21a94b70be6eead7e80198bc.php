

<?php $__env->startSection('content'); ?>
<h1>Hello</h1>

<table class="table table-striped table-dark">
<tr>
    <td>ID</td>
    <td>Name</td>
    <td>Edit</td>
    <td>Delete</td>
</tr>
    
    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    
    <tr>
        <td><?php echo e($patient->id); ?></td>
        <td>
            <a href="<?php echo e(route('hospital.show', $patient->id)); ?>"><?php echo e($patient->name); ?></a>
        </td>
        <td>Edit</td>
        <td>
            <form action="<?php echo e(route('hospital.destroy', $patient->id)); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <input type="submit" value="Trash" class="btn btn-danger">
                
            </form>
        </td>
    </tr>
    
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan=4>No data available</td>
    </tr>
    
    <?php endif; ?>
    
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\milan\Desktop\MCA SEM-2\Laravel\myexam-9.0\resources\views/user/index.blade.php ENDPATH**/ ?>
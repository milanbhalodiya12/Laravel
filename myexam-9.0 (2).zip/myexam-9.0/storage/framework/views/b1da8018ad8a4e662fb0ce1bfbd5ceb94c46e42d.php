

<?php $__env->startSection('content'); ?>
<h1>Patients detail !</h1>

<h5>Patient Name : <?php echo e($hospital->name); ?></h5>
<h6>Medicines : <?php echo e($hospital->medicine); ?></h6>
<h6>Disease : <?php echo e($hospital->disease); ?></h6>

<form action="" method="post">
    <?php echo csrf_field(); ?>
<div class="form-group">
    <label >Visits</label>
    <textarea class="form-control" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\milan\Desktop\MCA SEM-2\Laravel\myexam-9.0\resources\views/user/show.blade.php ENDPATH**/ ?>
<hr>
<footer>Copyrigth information goes here</footer><?php /**PATH C:\Users\milan\Desktop\MCA SEM-2\Laravel\myexam-9.0\resources\views/template/footer.blade.php ENDPATH**/ ?>
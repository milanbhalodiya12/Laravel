@extends('template.layout')

@section('content')
<h1>Hello</h1>

<table class="table table-striped table-dark">
<tr>
    <td>ID</td>
    <td>Name</td>
    <td>Edit</td>
    <td>Delete</td>
</tr>
    
    @forelse($patients as $patient)
    
    <tr>
        <td>{{$patient->id}}</td>
        <td>
            <a href="{{ route('hospital.show', $patient->id) }}">{{$patient->name}}</a>
        </td>
        <td>Edit</td>
        <td>
            <form action="{{ route('hospital.destroy', $patient->id) }}" method="post" >
                @csrf
                @method('delete')
                <input type="submit" value="Trash" class="btn btn-danger">
                
            </form>
        </td>
    </tr>
    
    
    @empty
    <tr>
        <td colspan=4>No data available</td>
    </tr>
    
    @endforelse
    
</table>
@endsection
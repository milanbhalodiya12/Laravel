<form action="{{ route('hospital.store') }}" method="post">
    @csrf
  <div class="form-group">
    <label >Name</label>
    <input type="text" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label>Mobile</label>
    <input type="number" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label >Diseases</label>
    <input type="text" name="name" class="form-control" ">
  </div>
  <div class="form-group">
    <label >Medicines</label>
    <input type="text" name="name" class="form-control" ">
  </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
@extends('template.layout')

@section('content')
<h1>Patients detail !</h1>

<h5>Patient Name : {{$hospital->name}}</h5>
<h6>Medicines : {{$hospital->medicine}}</h6>
<h6>Disease : {{$hospital->disease}}</h6>

<form action="" method="post">
    @csrf
<div class="form-group">
    <label >Visits</label>
    <textarea class="form-control" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection
<hr>
<footer>Copyrigth information goes here</footer>
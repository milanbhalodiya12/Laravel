<?php

namespace App\Http\Controllers;

use App\Models\Hospital;
use Illuminate\Http\Request;

class HospitalController extends Controller
{
    public function index()
    {
        $patients = Hospital::get();
        return view('user.index',compact('patients'));
    }
    public function create()
    {
        return view('user.create');
    }

    public function store(Request $request)
    {
        $hospital = new Hospital();
        $hospital->create( $request->all());
        return redirect()->route('hospital.index');
    }

    public function show(Hospital $hospital)
    {
        return view('user.show',compact('hospital'));
    }

    
    public function edit(Hospital $hospital)
    {
        //
    }


    public function update(Request $request, Hospital $hospital)
    {
        //
    }

   
    public function destroy(Hospital $hospital)
    {
        $hospital->delete();
        return redirect()->route('hospital.index');
    }
}
